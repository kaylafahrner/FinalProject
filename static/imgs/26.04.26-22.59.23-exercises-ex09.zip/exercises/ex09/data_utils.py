"""Data related utility functions."""

__author__ = "730756650"

from csv import DictReader


def get_keys(input_dict: dict) -> list[str]:
    """Returns a list of keys from a dictionary."""
    result: list[str] = []
    for key in input_dict:
        result.append(key)
    return result


def read_csv_rows(filename: str) -> list[dict[str, str]]:
    """Read the rows of a CSV into a 'table'."""
    result: list[dict[str, str]] = []
    file_handle = open(filename, "r", encoding="utf8")
    csv_reader = DictReader(file_handle)
    for row in csv_reader:
        result.append(row)
    file_handle.close()
    return result


def column_values(table: list[dict[str, str]], column: str) -> list[str]:
    """Produce a list[str] of all values in a single column."""
    result: list[str] = []
    for row in table:
        result.append(row[column])
    return result


def columnar(row_table: list[dict[str, str]]) -> dict[str, list[str]]:
    """Transform a row-oriented table to a column-oriented table."""
    result: dict[str, list[str]] = {}
    if len(row_table) == 0:
        return result
    first_row: dict[str, str] = row_table[0]
    for column in first_row:
        result[column] = column_values(row_table, column)
    return result


def head(table: dict[str, list[str]], row_count: int) -> dict[str, list[str]]:
    """Visualize first few rows of a table."""
    result: dict[str, list[str]] = {}
    for column in table:
        column_values: list[str] = []
        rows_to_copy = row_count
        if row_count > len(table[column]):
            rows_to_copy = len(table[column])
        for i in range(rows_to_copy):
            column_values.append(table[column][i])
        result[column] = column_values
    return result


def select(data: dict[str, list[str]], names: list[str]) -> dict[str, list[str]]:
    """Produce a new column-based table."""
    result_dict: dict[str, list[str]] = {}
    for column_name in names:
        result_dict[column_name] = data[column_name]
    return result_dict


def concat(
    table_one: dict[str, list[str]], table_two: dict[str, list[str]]
) -> dict[str, list[str]]:
    """Combine two tables."""
    result: dict[str, list[str]] = {}
    for column in table_one:
        result[column] = table_one[column]
    for column in table_two:
        if column in result:
            result[column] += table_two[column]
        else:
            result[column] = table_two[column]
    return result


def count(frequency: list[str]) -> dict[str, int]:
    """Produce a dictionary where each key is a unique value."""
    result: dict[str, int] = {}
    for item in frequency:
        if item in result:
            result[item] += 1
        else:
            result[item] = 1
    return result


def convert_columns_to_int(
    data: dict[str, list[str]], columns_conv: list[str]
) -> dict[str, list[str | int]]:
    """Convert string columns to integers for plotting."""
    data_converted: dict[str, list[int | str]] = {}
    for col_name in data:
        data_converted[col_name] = []
        for value in data[col_name]:
            if col_name in columns_conv:
                data_converted[col_name].append(int(value))
            else:
                data_converted[col_name].append(value)
    return data_converted
